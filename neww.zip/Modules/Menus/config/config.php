<?php

return [
    'name' => 'Menus',
];
