<?php

return [
    'name' => 'Coupons',
];
