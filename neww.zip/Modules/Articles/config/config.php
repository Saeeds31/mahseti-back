<?php

return [
    'name' => 'Articles',
];
