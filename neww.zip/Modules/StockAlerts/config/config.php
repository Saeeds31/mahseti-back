<?php

return [
    'name' => 'StockAlerts',
];
