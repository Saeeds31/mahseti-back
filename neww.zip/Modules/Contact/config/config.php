<?php

return [
    'name' => 'Contact',
];
