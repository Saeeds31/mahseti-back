<?php

return [
    'name' => 'Specifications',
];
