<?php

return [
    'name' => 'Campaign',
];
