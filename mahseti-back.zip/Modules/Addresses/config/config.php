<?php

return [
    'name' => 'Addresses',
];
