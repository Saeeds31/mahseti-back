<?php

namespace Modules\Locations\Models;

use App\Support\CacheService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\Locations\Database\Factories\CityFactory;

class City extends Model
{
    use HasFactory;
    protected $fillable = ['name', 'province_id', 'wp_added'];
    public function province()
    {
        return $this->belongsTo(Province::class);
    }
    protected static function booted(): void
    {
        $clearCache = fn() => CacheService::forgetCities();
        static::saved($clearCache);
        static::deleted($clearCache);
    }
}
